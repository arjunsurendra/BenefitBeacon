# BenefitBeacon Application Guide extension

The BenefitBeacon browser extension keeps the selected program guide beside an official application in Chrome or Microsoft Edge. It can explain form fields, highlight them on the page, and offer a small set of profile-based suggestions. Every fill requires resident approval.

## Install for the demo

1. Start BenefitBeacon at `http://localhost:3000`.
2. Open `chrome://extensions` in Chrome or `edge://extensions` in Edge.
3. Turn on **Developer mode**.
4. Choose **Load unpacked** and select this `extension` folder.
5. Pin **BenefitBeacon Application Guide** to the browser toolbar.

## Use it

1. Find a program in BenefitBeacon and choose **Apply with BenefitBeacon**.
2. The official application opens in a new tab and the selected program conversation is handed to the extension.
3. Select the BenefitBeacon toolbar icon to open the side panel.
4. Choose **Connect to this page**. The browser asks for access to that official site's origin the first time.
5. Review field explanations, highlight a field, or approve an offered fill one field at a time.

If the local app uses a different port, open **Local connection** at the bottom of the side panel and update the address.

## Safety boundaries

- Reads visible field labels, select options, and whether a field is complete; it does not read or transmit entered values.
- Never fills passwords, Social Security numbers, bank details, signatures, identity-document numbers, full birth dates, or file uploads.
- Never submits, signs, accepts terms, bypasses verification, or clicks through an application.
- Requests access only to the official site the resident chooses to connect.
- Stores the handoff, safe profile facts, settings, and recent program chat locally in the browser profile.
- Uses BenefitBeacon's existing `/api/program-chat` endpoint for sourced program guidance. The OpenAI API key remains on the server and is never packaged in the extension.

Some application forms embedded in protected cross-origin frames cannot be inspected. The side-panel chat and official page link remain available in that case.
