/* global chrome */

(() => {
  if (window.__benefitBeaconFormGuideInstalled) return;
  window.__benefitBeaconFormGuideInstalled = true;

  const fieldMap = new Map();
  const blockedInputTypes = new Set(["file", "password", "hidden", "submit", "button", "reset", "image"]);
  const sensitivePattern = /social\s*security|\bssn\b|taxpayer|routing|bank|account\s*(number|no\.?|#)|password|passcode|\bpin\b|signature|alien\s*(number|registration)|passport|driver.?s?\s*licen[cs]e|document\s*(number|id)|full\s*date\s*of\s*birth|\bdob\b/i;

  function visible(element) {
    const style = window.getComputedStyle(element);
    const rect = element.getBoundingClientRect();
    return style.display !== "none" && style.visibility !== "hidden" && rect.width > 0 && rect.height > 0;
  }

  function normalizedText(value) {
    return String(value ?? "").replace(/\s+/g, " ").trim();
  }

  function labelFor(element) {
    const labels = element.labels ? [...element.labels].map((label) => label.innerText) : [];
    const closestLabel = element.closest("label")?.innerText;
    const fieldset = element.closest("fieldset")?.querySelector("legend")?.innerText;
    return normalizedText(
      element.getAttribute("aria-label")
      || element.getAttribute("aria-labelledby")?.split(/\s+/).map((id) => document.getElementById(id)?.innerText).filter(Boolean).join(" ")
      || labels.join(" ")
      || closestLabel
      || element.getAttribute("placeholder")
      || fieldset
      || element.getAttribute("name")
      || element.id
      || "Unlabeled field",
    ).slice(0, 240);
  }

  function isSensitive(element, label) {
    const description = [
      label,
      element.getAttribute("name"),
      element.id,
      element.getAttribute("autocomplete"),
      element.getAttribute("placeholder"),
      element.getAttribute("type"),
    ].filter(Boolean).join(" ");
    return element.type === "password" || sensitivePattern.test(description);
  }

  function pageSummary() {
    let pageUrl = "";
    let formAction = "";
    try {
      const url = new URL(window.location.href);
      pageUrl = `${url.origin}${url.pathname}`;
      const action = document.querySelector("form")?.action;
      if (action) {
        const actionUrl = new URL(action, window.location.href);
        formAction = `${actionUrl.origin}${actionUrl.pathname}`;
      }
    } catch {
      pageUrl = "";
    }
    return { title: normalizedText(document.title).slice(0, 180), pageUrl, formAction };
  }

  function scanFields() {
    fieldMap.clear();
    const elements = [...document.querySelectorAll("input, select, textarea")]
      .filter((element) => !element.disabled && !blockedInputTypes.has(element.type) && visible(element));

    const fields = elements.slice(0, 120).map((element, index) => {
      const id = `field-${index + 1}`;
      const label = labelFor(element);
      const sensitive = isSensitive(element, label);
      fieldMap.set(id, element);
      const options = element instanceof HTMLSelectElement
        ? [...element.options].slice(0, 60).map((option) => ({ value: option.value.slice(0, 120), text: normalizedText(option.text).slice(0, 120) }))
        : [];
      return {
        id,
        label,
        tag: element.tagName.toLowerCase(),
        type: element.type || element.tagName.toLowerCase(),
        required: element.required || element.getAttribute("aria-required") === "true",
        autocomplete: normalizedText(element.getAttribute("autocomplete")).slice(0, 80),
        sensitive,
        hasValue: element.type === "checkbox" || element.type === "radio" ? element.checked : Boolean(element.value),
        options,
      };
    });

    return { ...pageSummary(), fields };
  }

  function highlightField(id) {
    const element = fieldMap.get(id);
    if (!element) return { ok: false, error: "Field not found. Scan the page again." };
    element.scrollIntoView({ behavior: "smooth", block: "center" });
    const previousOutline = element.style.outline;
    const previousOffset = element.style.outlineOffset;
    element.style.outline = "4px solid #ef7054";
    element.style.outlineOffset = "4px";
    element.focus({ preventScroll: true });
    window.setTimeout(() => {
      element.style.outline = previousOutline;
      element.style.outlineOffset = previousOffset;
    }, 3500);
    return { ok: true };
  }

  function fillField(id, rawValue) {
    const element = fieldMap.get(id);
    if (!element) return { ok: false, error: "Field not found. Scan the page again." };
    const label = labelFor(element);
    if (isSensitive(element, label)) return { ok: false, error: "BenefitBeacon never fills sensitive identifiers." };
    const value = normalizedText(rawValue).slice(0, 300);
    if (!value) return { ok: false, error: "No suggested value is available." };

    if (element instanceof HTMLSelectElement) {
      const target = [...element.options].find((option) => {
        const optionValue = normalizedText(option.value).toLowerCase();
        const optionText = normalizedText(option.text).toLowerCase();
        return optionValue === value.toLowerCase() || optionText === value.toLowerCase();
      });
      if (!target) return { ok: false, error: "The suggested value does not match an available option." };
      const selectSetter = Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, "value")?.set;
      selectSetter?.call(element, target.value);
    } else if (element.type === "checkbox" || element.type === "radio") {
      const checkedSetter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "checked")?.set;
      checkedSetter?.call(element, /^(yes|true|1|checked)$/i.test(value));
    } else if (element instanceof HTMLInputElement) {
      const inputSetter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value")?.set;
      inputSetter?.call(element, value);
    } else if (element instanceof HTMLTextAreaElement) {
      const textareaSetter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, "value")?.set;
      textareaSetter?.call(element, value);
    } else {
      return { ok: false, error: "This field type is not supported." };
    }

    element.dispatchEvent(new Event("input", { bubbles: true }));
    element.dispatchEvent(new Event("change", { bubbles: true }));
    highlightField(id);
    return { ok: true };
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === "BENEFITBEACON_SCAN_FORM") {
      sendResponse({ ok: true, page: scanFields() });
      return false;
    }
    if (message?.type === "BENEFITBEACON_HIGHLIGHT_FIELD") {
      sendResponse(highlightField(message.fieldId));
      return false;
    }
    if (message?.type === "BENEFITBEACON_FILL_FIELD") {
      sendResponse(fillField(message.fieldId, message.value));
      return false;
    }
    return false;
  });
})();
