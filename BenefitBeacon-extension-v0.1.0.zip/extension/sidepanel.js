/* global chrome */

const SESSION_KEY = "benefitbeaconApplicationSession";
const SETTINGS_KEY = "benefitbeaconExtensionSettings";
const CHAT_KEY = "benefitbeaconApplicationChats";

const state = {
  session: null,
  page: null,
  tab: null,
  messages: [],
  loading: false,
  settings: { apiBase: "http://localhost:3000" },
};

const ui = Object.fromEntries([
  "empty-state", "guide", "program-name", "program-benefit", "program-summary", "official-link",
  "page-title", "page-host", "connect-button", "connection-message", "form-guide", "field-progress",
  "progress-bar", "field-list", "rescan-button", "messages", "chat-form", "chat-input", "api-base",
  "save-settings",
].map((id) => [id.replaceAll("-", "_"), document.getElementById(id)]));

function normalize(value) {
  return String(value ?? "").replace(/\s+/g, " ").trim();
}

function safeUrl(value) {
  try {
    const url = new URL(value);
    return ["http:", "https:"].includes(url.protocol) ? url : null;
  } catch {
    return null;
  }
}

function setConnectionMessage(text, error = false) {
  ui.connection_message.textContent = text;
  ui.connection_message.classList.toggle("error", error);
}

async function activeTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  state.tab = tab ?? null;
  return state.tab;
}

function applicationOriginPattern(tab) {
  const url = safeUrl(tab?.url);
  if (!url) return null;
  return `${url.origin}/*`;
}

async function ensurePageAccess(tab) {
  const pattern = applicationOriginPattern(tab);
  if (!pattern) throw new Error("Open an official application page first.");
  if (pattern.startsWith("http://localhost:3000/") || pattern.startsWith("http://127.0.0.1:3000/")) return true;
  const allowed = await chrome.permissions.contains({ origins: [pattern] });
  if (allowed) return true;
  return chrome.permissions.request({ origins: [pattern] });
}

async function sendToPage(message) {
  const tab = await activeTab();
  if (!tab?.id) throw new Error("No active application page was found.");
  const allowed = await ensurePageAccess(tab);
  if (!allowed) throw new Error("Page access was not approved. BenefitBeacon cannot read the form labels.");
  await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content.js"] });
  return chrome.tabs.sendMessage(tab.id, message);
}

function optionValue(field, desired) {
  if (!field.options?.length) return desired;
  const target = normalize(desired).toLowerCase();
  const option = field.options.find((item) => normalize(item.value).toLowerCase() === target || normalize(item.text).toLowerCase() === target)
    || field.options.find((item) => normalize(item.text).toLowerCase().includes(target));
  return option?.value ?? null;
}

function suggestionFor(field) {
  if (!state.session || field.sensitive) return null;
  const profile = state.session.profile ?? {};
  const label = `${field.label} ${field.autocomplete}`.toLowerCase();
  let value = null;

  if (/\b(city|town)\b/.test(label)) value = profile.city;
  else if (/\b(state|province)\b/.test(label)) value = profile.state;
  else if (/\b(zip|postal)\b/.test(label)) value = profile.zip;
  else if (/household.*(size|members|people)|number.*household/.test(label)) value = profile.householdSize;
  else if (/housing|residence.*type|rent.*own|homeowner/.test(label)) value = profile.housing === "own" ? "Own" : profile.housing === "rent" ? "Rent" : null;
  else if (/active.?duty|currently serving/.test(label) && typeof profile.activeDuty === "boolean") value = profile.activeDuty ? "Yes" : "No";
  else if (/veteran|military service/.test(label) && typeof profile.veteran === "boolean") value = profile.veteran ? "Yes" : "No";
  else if (/disab/.test(label) && typeof profile.disabled === "boolean") value = profile.disabled ? "Yes" : "No";
  else if (/caregiver|unpaid care/.test(label) && typeof profile.caregiver === "boolean") value = profile.caregiver ? "Yes" : "No";
  else if (/employment|work status/.test(label) && profile.employment) value = profile.employment[0].toUpperCase() + profile.employment.slice(1);

  if (value === null || value === undefined || value === "") return null;
  const fillValue = optionValue(field, String(value));
  if (fillValue === null) return null;
  return { display: String(value), value: fillValue };
}

function button(label, className, onClick, disabled = false) {
  const element = document.createElement("button");
  element.type = "button";
  element.textContent = label;
  if (className) element.className = className;
  element.disabled = disabled;
  element.addEventListener("click", onClick);
  return element;
}

async function highlightField(fieldId) {
  try {
    const response = await sendToPage({ type: "BENEFITBEACON_HIGHLIGHT_FIELD", fieldId });
    if (!response?.ok) throw new Error(response?.error || "That field could not be highlighted.");
  } catch (error) {
    setConnectionMessage(error.message || "That field could not be highlighted.", true);
  }
}

async function fillField(field, suggestion) {
  const confirmed = window.confirm(`Fill “${field.label}” with “${suggestion.display}”?\n\nBenefitBeacon will not submit the form.`);
  if (!confirmed) return;
  try {
    const response = await sendToPage({ type: "BENEFITBEACON_FILL_FIELD", fieldId: field.id, value: suggestion.value });
    if (!response?.ok) throw new Error(response?.error || "That field could not be filled.");
    await scanPage(false);
    setConnectionMessage(`Filled “${field.label}”. Review it on the page before continuing.`);
  } catch (error) {
    setConnectionMessage(error.message || "That field could not be filled.", true);
  }
}

function renderFields() {
  ui.field_list.replaceChildren();
  const fields = state.page?.fields ?? [];
  const completed = fields.filter((field) => field.hasValue).length;
  ui.field_progress.textContent = `${completed} of ${fields.length} complete`;
  ui.progress_bar.style.width = fields.length ? `${Math.round((completed / fields.length) * 100)}%` : "0%";

  if (!fields.length) {
    const empty = document.createElement("p");
    empty.className = "connection-message";
    empty.textContent = "No visible form fields were found on this page. The application may be inside a protected frame or require another step first.";
    ui.field_list.append(empty);
    return;
  }

  fields.forEach((field) => {
    const item = document.createElement("article");
    item.className = "field-item";
    const title = document.createElement("div");
    title.className = "field-title";
    const name = document.createElement("strong");
    name.textContent = field.label;
    const badges = document.createElement("div");
    badges.className = "field-badges";
    if (field.required) {
      const required = document.createElement("span");
      required.textContent = "Required";
      badges.append(required);
    }
    if (field.hasValue) {
      const complete = document.createElement("span");
      complete.textContent = "Complete";
      badges.append(complete);
    }
    if (field.sensitive) {
      const sensitive = document.createElement("span");
      sensitive.className = "sensitive";
      sensitive.textContent = "Private—enter yourself";
      badges.append(sensitive);
    }
    title.append(name, badges);
    item.append(title);

    const suggestion = suggestionFor(field);
    if (suggestion) {
      const suggestionText = document.createElement("p");
      suggestionText.className = "field-suggestion";
      suggestionText.append("From what you shared: ");
      const strong = document.createElement("b");
      strong.textContent = suggestion.display;
      suggestionText.append(strong);
      item.append(suggestionText);
    }

    const actions = document.createElement("div");
    actions.className = "field-actions";
    actions.append(button("Show on page", "", () => highlightField(field.id)));
    actions.append(button("Ask about this", "", () => askQuestion(`I see an application field labeled “${field.label}”. What does this field mean, what information should I use, and what should I prepare? Do not ask me to send the value here.`)));
    if (suggestion) actions.append(button(`Fill “${suggestion.display}”`, "fill-button", () => fillField(field, suggestion), field.sensitive));
    item.append(actions);
    ui.field_list.append(item);
  });
}

async function scanPage(requestPermission = true) {
  ui.connect_button.disabled = true;
  ui.connect_button.firstChild.textContent = requestPermission ? "Connecting… " : "Refreshing… ";
  setConnectionMessage("");
  try {
    const response = await sendToPage({ type: "BENEFITBEACON_SCAN_FORM" });
    if (!response?.ok || !response.page) throw new Error("BenefitBeacon could not read this page.");
    state.page = response.page;
    const url = safeUrl(response.page.pageUrl);
    ui.page_title.textContent = response.page.title || "Application page";
    ui.page_host.textContent = url?.hostname || "Connected application";
    ui.form_guide.hidden = false;
    ui.connect_button.firstChild.textContent = "Connected ";
    setConnectionMessage("Connected. BenefitBeacon reads labels and completion status only.");
    renderFields();
  } catch (error) {
    ui.connect_button.firstChild.textContent = "Try connecting again ";
    setConnectionMessage(error.message || "BenefitBeacon could not connect to this page.", true);
  } finally {
    ui.connect_button.disabled = false;
  }
}

function renderMessages() {
  ui.messages.replaceChildren();
  if (!state.messages.length) {
    const welcome = document.createElement("article");
    welcome.className = "message";
    const label = document.createElement("span");
    label.textContent = "BenefitBeacon";
    const text = document.createElement("p");
    text.textContent = "I’m still with you. Ask what a field means, what documents to prepare, or what the next step requires.";
    welcome.append(label, text);
    ui.messages.append(welcome);
  }

  state.messages.forEach((message) => {
    const article = document.createElement("article");
    article.className = `message ${message.role}`;
    const label = document.createElement("span");
    label.textContent = message.role === "user" ? "You" : "BenefitBeacon";
    const text = document.createElement("p");
    text.textContent = message.text;
    article.append(label, text);
    if (message.role === "assistant" && Array.isArray(message.sources) && message.sources.length) {
      const sources = document.createElement("div");
      sources.className = "message-sources";
      message.sources.slice(0, 5).forEach((source) => {
        const url = safeUrl(source.url);
        if (!url || url.protocol !== "https:") return;
        const link = document.createElement("a");
        link.href = url.href;
        link.target = "_blank";
        link.rel = "noreferrer";
        link.textContent = `${source.title || url.hostname} ↗`;
        sources.append(link);
      });
      article.append(sources);
    }
    ui.messages.append(article);
  });

  if (state.loading) {
    const thinking = document.createElement("article");
    thinking.className = "message thinking";
    const dots = document.createElement("span");
    dots.className = "thinking-dots";
    dots.append(document.createElement("i"), document.createElement("i"), document.createElement("i"));
    const text = document.createElement("p");
    text.textContent = "Checking the program instructions…";
    thinking.append(dots, text);
    ui.messages.append(thinking);
  }
  ui.messages.scrollTop = ui.messages.scrollHeight;
}

async function saveMessages() {
  if (!state.session?.program?.id) return;
  const stored = await chrome.storage.local.get(CHAT_KEY);
  const chats = stored[CHAT_KEY] && typeof stored[CHAT_KEY] === "object" ? stored[CHAT_KEY] : {};
  chats[state.session.program.id] = state.messages.slice(-20);
  await chrome.storage.local.set({ [CHAT_KEY]: chats });
}

async function askQuestion(rawQuestion) {
  const question = normalize(rawQuestion);
  if (!question || state.loading || !state.session?.program) return;
  const history = state.messages.slice(-8);
  state.messages.push({ role: "user", text: question });
  state.loading = true;
  renderMessages();
  ui.chat_input.value = "";
  const submit = ui.chat_form.querySelector("button[type='submit']");
  submit.disabled = true;

  try {
    const apiBase = normalize(state.settings.apiBase || state.session.apiBase).replace(/\/$/, "");
    const response = await fetch(`${apiBase}/api/program-chat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        programId: state.session.program.id,
        program: state.session.program,
        question,
        history,
        profile: state.session.profile ?? {},
      }),
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok || typeof payload.answer !== "string") throw new Error(payload.error || "BenefitBeacon could not answer right now.");
    state.messages.push({ role: "assistant", text: payload.answer, needsMoreInfo: payload.needsMoreInfo === true, sources: payload.sources ?? [] });
  } catch (error) {
    state.messages.push({ role: "assistant", text: error.message || "BenefitBeacon could not answer right now. You can continue reviewing the official page." });
  } finally {
    state.loading = false;
    submit.disabled = false;
    renderMessages();
    await saveMessages();
  }
}

async function renderSession() {
  const session = state.session;
  ui.empty_state.hidden = Boolean(session);
  ui.guide.hidden = !session;
  if (!session) return;

  const program = session.program;
  ui.program_name.textContent = program.name;
  ui.program_benefit.textContent = program.benefit || "";
  ui.program_summary.textContent = program.summary || "";
  ui.official_link.href = safeUrl(program.sourceUrl)?.href || safeUrl(program.applyUrl)?.href || "#";
  state.settings.apiBase = state.settings.apiBase || session.apiBase || "http://localhost:3000";
  ui.api_base.value = state.settings.apiBase;

  const stored = await chrome.storage.local.get(CHAT_KEY);
  const existing = stored[CHAT_KEY]?.[program.id];
  state.messages = Array.isArray(existing) && existing.length ? existing : Array.isArray(session.history) ? session.history.slice(-12) : [];
  renderMessages();

  const tab = await activeTab();
  const tabUrl = safeUrl(tab?.url);
  if (tabUrl && !["localhost", "127.0.0.1"].includes(tabUrl.hostname)) {
    ui.page_title.textContent = tab?.title || "Application page";
    ui.page_host.textContent = tabUrl.hostname;
  }
}

async function saveSettings() {
  const url = safeUrl(ui.api_base.value);
  if (!url || !["http:", "https:"].includes(url.protocol)) {
    ui.api_base.setCustomValidity("Enter a valid BenefitBeacon address.");
    ui.api_base.reportValidity();
    return;
  }
  ui.api_base.setCustomValidity("");
  state.settings.apiBase = url.origin;
  await chrome.storage.local.set({ [SETTINGS_KEY]: state.settings });
  ui.save_settings.textContent = "Saved";
  window.setTimeout(() => { ui.save_settings.textContent = "Save"; }, 1400);
}

ui.connect_button.addEventListener("click", () => scanPage(true));
ui.rescan_button.addEventListener("click", () => scanPage(false));
ui.chat_form.addEventListener("submit", (event) => {
  event.preventDefault();
  askQuestion(ui.chat_input.value);
});
document.querySelectorAll("[data-question]").forEach((element) => element.addEventListener("click", () => askQuestion(element.dataset.question)));
ui.save_settings.addEventListener("click", saveSettings);

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local" || !changes[SESSION_KEY]) return;
  state.session = changes[SESSION_KEY].newValue ?? null;
  state.page = null;
  ui.form_guide.hidden = true;
  renderSession();
});

chrome.tabs.onActivated.addListener(() => {
  if (!state.session) return;
  activeTab().then((tab) => {
    const url = safeUrl(tab?.url);
    if (url) {
      ui.page_title.textContent = tab.title || "Application page";
      ui.page_host.textContent = url.hostname;
    }
  });
});

async function init() {
  const stored = await chrome.storage.local.get([SESSION_KEY, SETTINGS_KEY]);
  state.session = stored[SESSION_KEY] ?? null;
  state.settings = { ...state.settings, ...(stored[SETTINGS_KEY] ?? {}) };
  await renderSession();
}

init().catch(() => {
  ui.empty_state.hidden = false;
  ui.guide.hidden = true;
});
